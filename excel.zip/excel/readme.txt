
1. Extract the zip file.
2. create database "excelimport".
3. Goto db folder. 
4. Import "excelimport.sql" file into database.
5. Example excel file "users.xlsx" 

run and enjoy.

thanks.

