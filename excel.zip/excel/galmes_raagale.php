<?php
session_start();

if(strlen($_SESSION['slogin'])==0)
    {   
header('location:index.php');
}




use Box\Spout\Reader\ReaderFactory;
use Box\Spout\Common\Type;

require_once ('connect.php');
require_once ('Spout/Autoloader/autoload.php');

if(!empty($_FILES['excelfile']['name']))
{
    // Get File extension eg. 'xlsx' to check file is excel sheet
    $pathinfo = pathinfo($_FILES['excelfile']['name']);

    // check file has extension xlsx, xls and also check
    // file is not empty
    if (($pathinfo['extension'] == 'xlsx' || $pathinfo['extension'] == 'xls')
        && $_FILES['excelfile']['size'] > 0 )
    {
        $file = $_FILES['excelfile']['tmp_name'];

        // Read excel file by using ReadFactory object.
        $reader = ReaderFactory::create(Type::XLSX);

        // Open file
        $reader->open($file);
        $count = 0;

        // Number of sheet in excel file
        foreach ($reader->getSheetIterator() as $sheet)
        {

            // Number of Rows in Excel sheet
            foreach ($sheet->getRowIterator() as $row)
            {

                // It reads data after header. In the my excel sheet,
                // header is in the first row.
                if ($count > 0) {

                    // Data of excel sheet
		
                    $serv_id =mysqli_real_escape_string($con, $row[0]);
                    $lgaa = mysqli_real_escape_string($con, $row[1]);
					$lgmm =mysqli_real_escape_string($con, $row[2]);
                    $cr = mysqli_real_escape_string($con, $row[3]);
					$mshakama = mysqli_real_escape_string($con, $row[4]);
                    $mmidhama = mysqli_real_escape_string($con, $row[5]);
					$teessoo = mysqli_real_escape_string($con, $row[6]);
                    $gyakkaa = mysqli_real_escape_string($con, $row[7]);
					$gosa_yakkaa = mysqli_real_escape_string($con, $row[8]);
                    $kew_seeraa = mysqli_real_escape_string($con, $row[9]);
					$umurii = mysqli_real_escape_string($con, $row[10]);
					
					   $saala =mysqli_real_escape_string($con, $row[11]);
                    $ghbaname = mysqli_real_escape_string($con, $row[12]);
					$maa =mysqli_real_escape_string($con, $row[13]);
                    $murtii = mysqli_real_escape_string($con, $row[14]);
					$gmkenname = mysqli_real_escape_string($con, $row[15]);
                    $sgcufame = mysqli_real_escape_string($con, $row[16]);
					$ggcufame = mysqli_real_escape_string($con, $row[17]);
                    $golgafatame = mysqli_real_escape_string($con, $row[18]);
					$golergame = mysqli_real_escape_string($con, $row[19]);
                    $qpoolisii = mysqli_real_escape_string($con, $row[20]);
					$gergame = mysqli_real_escape_string($con, $row[21]);
					
					   $gdhiyate =mysqli_real_escape_string($con, $row[22]);
                    $tatiba = mysqli_real_escape_string($con, $row[23]);
					$bshakamadhi =mysqli_real_escape_string($con, $row[24]);
                    $bshakamadha = mysqli_real_escape_string($con, $row[25]);
					$geeruu = mysqli_real_escape_string($con, $row[26]);
                    $gwdhufe = mysqli_real_escape_string($con, $row[27]);
					$qekenne = mysqli_real_escape_string($con, $row[28]);
                    $bfgalmee = mysqli_real_escape_string($con, $row[29]);
					$golhordofame = mysqli_real_escape_string($con, $row[30]);
                    $rseeraa = mysqli_real_escape_string($con, $row[31]);
					$rittidha = mysqli_real_escape_string($con, $row[32]);
					
					$dhidhiyate = mysqli_real_escape_string($con, $row[33]);
                    $qdhiyeesse = mysqli_real_escape_string($con, $row[34]);
					$mwabii = mysqli_real_escape_string($con, $row[35]);
                    $qarshii = mysqli_real_escape_string($con, $row[36]);
					
					
		
                    //Here, You can insert data into database.
                    $query = "INSERT INTO `aqymhk`(`serv_id`, `lgaa`,`lgmm`, `cr`,`mshakama`, `mmidhama`,`teessoo`, `gyakkaa`,`gosa_yakkaa`, `kew_seeraa`,`umurii`, `saala`, `ghbaname`, `maa`,`murtii`, `gmkenname`,`sgcufame`, `ggcufame`,`golgafatame`, `golergame`,`qpoolisii`, `gergame`,`gdhiyate`, `tatiba`,       `bshakamadhi`, `bshakamadha`,`geeruu`, `gwdhufe`,`qekenne`, `bfgalmee`,`golhordofame`, `rseeraa`,`rittidha`, `dhidhiyate`,`qdhiyeesse`, `mwabii`, `qarshii`) VALUES ('$serv_id','$lgaa','$lgmm','$cr','$mshakama','$mmidhama','$teessoo','$gyakkaa','$gosa_yakkaa','$kew_seeraa','$umurii', '$saala', '$ghbaname','$maa','$murtii','$gmkenname','$sgcufame','$ggcufame','$golgafatame','$golergame','$qpoolisii','$gergame','$gdhiyate', '$tatiba', '$bshakamadhi','$bshakamadha','$geeruu','$gwdhufe','$qekenne','$bfgalmee', '$golhordofame', '$rseeraa','$rittidha','$dhidhiyate','$qdhiyeesse', '$mwabii', '$qarshii')";
                    $query = mysqli_query($con,$query);

                }
                $count++;
            }
        }

        if($query)
        {
            echo "Your file Uploaded Successfull";
        }
        else
        {
            echo "Your file Uploaded Failed";
        }

        // Close excel file
        $reader->close();
    }
    else
    {
        echo "Please Choose only Excel file";
    }
}
else
{
    echo "File is Empty"."<br>";
    echo "Please Choose Excel file";
}

?>
